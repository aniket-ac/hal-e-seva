package com.example.haleseva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HalESevaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HalESevaApplication.class, args);
	}

}
