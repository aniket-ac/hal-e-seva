package com.example.haleseva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HalESevaApplicationTests {

	@Test
	void contextLoads() {
	}

}
